#!/bin/bash
tar -czf /home/ubuntu/wp-backup-$(date +%F).tar.gz /var/www/html
